/*
 * @ASCK
 */

#include <systemc.h>
#include "../Controller.cpp"


using namespace std;

int sc_main(int argc, char* argv[]){
    cout << "starting Controller" << endl;


    /*
        YOUR TESTBENCH HERE
    */    

    return 0;
}
