/*
 * @ASCK
 */

#include <systemc.h>
#include "../IR.cpp"


using namespace std;

int sc_main(int argc, char* argv[]){
    cout << "starting IR" << endl;
    
    /*
        YOUR TESTBECH HERE
    */
    

    return 0;
}
